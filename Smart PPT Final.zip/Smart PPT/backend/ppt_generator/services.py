from pptx import Presentation
import os
from ai.model import generate_slide_content

def generate_ppt(title):
    prs = Presentation()
    slide_layout = prs.slide_layouts[1]
    
    content = generate_slide_content(title)
    
    slide = prs.slides.add_slide(slide_layout)
    title_placeholder = slide.shapes.title
    content_placeholder = slide.placeholders[1]
    title_placeholder.text = title
    content_placeholder.text = content
    
    file_path = f"generated_ppts/{title}.pptx"
    prs.save(file_path)
    
    return file_path
