document.querySelector('.generate').addEventListener('click', () => {
    alert("Generating content...");
});

// Create floating animated shapes
for (let i = 0; i < 15; i++) {
    let shape = document.createElement('div');
    shape.classList.add('floating-shapes');
    shape.style.left = `${Math.random() * 100}vw`;
    shape.style.top = `${Math.random() * 100}vh`;
    shape.style.animationDuration = `${Math.random() * 5 + 7}s`;
    document.body.appendChild(shape);
}
