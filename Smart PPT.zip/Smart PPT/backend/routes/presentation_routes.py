from flask import Blueprint, request, jsonify
from database.models import db
from ppt_generator.services import generate_ppt

presentation_bp = Blueprint('presentation', __name__)

@presentation_bp.route('/generate', methods=['POST'])
def create_presentation():
    data = request.json
    title = data.get('title')
    
    if not title:
        return jsonify({"error": "Title is required"}), 400
    
    file_path = generate_ppt(title)
    
    presentation = {
        "title": title,
        "file_path": file_path,
        "status": "completed"
    }
    db.presentations.insert_one(presentation)
    
    return jsonify({"message": "Presentation created successfully", "file_path": file_path})
