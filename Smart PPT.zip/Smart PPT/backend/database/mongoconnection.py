import gridfs
from pymongo import MongoClient
import os
from dotenv import load_dotenv

load_dotenv()  # Load environment variables

# MongoDB Connection
MONGO_URI = os.getenv("MONGO_URI")  # Get MongoDB URI from .env
client = MongoClient(MONGO_URI)
  # Database name
try:
    client.admin.command('ping')  # Test connection
    print("✅ Connected to MongoDB")
except Exception as e:
    print(f"❌ MongoDB Connection Error: {e}")

db = client["smart_ppt"]
fs = gridfs.GridFS(db)

def init_db():
    if "presentations" not in db.list_collection_names():
        db.create_collection("presentations")

# Collections
presentations_collection = db["presentations"]

print("✅ Connected to MongoDB")
