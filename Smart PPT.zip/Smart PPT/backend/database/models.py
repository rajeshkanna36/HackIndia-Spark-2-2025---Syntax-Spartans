from database.mongoconnection import db

def init_db():
    """Initialize collections in MongoDB only if they don't exist."""
    if "presentations" not in db.list_collection_names():
        db.create_collection("presentations")
        print("✅ Collection 'presentations' created.")
    else:
        print("⚠️ Collection 'presentations' already exists.")

