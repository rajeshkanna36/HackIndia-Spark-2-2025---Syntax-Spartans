from transformers import AutoModelForCausalLM, AutoTokenizer
import torch

MODEL_PATH = "meta-llama/Llama-2-7b-chat-hf"

def load_llama2():
    """Loads LLaMA 2 model and tokenizer"""
    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_PATH, torch_dtype=torch.float16, device_map="auto"
    )
    return model, tokenizer

llama_model, llama_tokenizer = load_llama2()


