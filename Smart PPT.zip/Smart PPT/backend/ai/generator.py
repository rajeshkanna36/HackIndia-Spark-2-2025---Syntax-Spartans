import os
from pptx import Presentation

def generate_presentation(topic):
    """Generate a simple PowerPoint presentation based on a given topic."""
    ppt = Presentation()
    slide_layout = ppt.slide_layouts[0]  # Title Slide

    # Create Title Slide
    slide = ppt.slides.add_slide(slide_layout)
    title = slide.shapes.title
    subtitle = slide.placeholders[1]

    title.text = topic
    subtitle.text = "An AI-Generated Presentation"

    # Save the presentation
    ppt_dir = "generated_ppts"
    os.makedirs(ppt_dir, exist_ok=True)
    ppt_path = os.path.join(ppt_dir, f"{topic.replace(' ', '_')}.pptx")
    ppt.save(ppt_path)

    return ppt_path
