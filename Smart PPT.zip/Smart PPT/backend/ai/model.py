import torch
from ai.llama_utils import llama_model, llama_tokenizer

def generate_slide_content(prompt):
    """Uses LLaMA 2 to generate slide content based on the given prompt"""
    inputs = llama_tokenizer(prompt, return_tensors="pt").to("cuda")
    
    with torch.no_grad():
        output = llama_model.generate(**inputs, max_length=200)
    
    generated_text = llama_tokenizer.decode(output[0], skip_special_tokens=True)
    
    return generated_text
