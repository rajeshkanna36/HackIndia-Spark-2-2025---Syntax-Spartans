from flask import Flask
from flask_cors import CORS
from database.mongoconnection import init_db  # ✅ Ensure this matches

def create_app():
    app = Flask(__name__)
    CORS(app)

    from routes.presentation_routes import presentation_bp
    

    init_db()  # ✅ Initialize the database

    return app




